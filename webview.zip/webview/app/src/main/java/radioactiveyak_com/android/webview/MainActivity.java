package radioactiveyak_com.android.webview;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.webkit.WebView;

public class MainActivity extends AppCompatActivity {
private WebView webView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        webView=new WebView(this);
        String url="file:///android_asset/home.html";
        webView.loadUrl(url);
        webView.getSettings().setJavaScriptEnabled(true);
        setContentView(webView);

    }
}
