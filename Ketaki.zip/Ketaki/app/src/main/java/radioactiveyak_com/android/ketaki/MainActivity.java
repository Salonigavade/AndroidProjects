package radioactiveyak_com.android.ketaki;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.ListView;

public class MainActivity extends AppCompatActivity implements OnClickListener{

    Toolbar toolBar;
    ListView listView;
    ImageView lastClickedRowImage;
    ImageView imageView;

    String[] country={"a","b","c","d"};
    int[] lion={R.drawable.lion1,
    R.drawable.lion2,
    R.drawable.lion3,
    R.drawable.lion4};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        toolBar=(Toolbar) findViewById(R.id.toolbar);
        toolBar.setTitle(getResources().getString(R.string.app_name));
        listView=(ListView) findViewById(R.id.listview);
        MyAdapter myAdapter=new MyAdapter(MainActivity.this,country,lion);
        listView.setAdapter(myAdapter);
        imageView=(ImageView)findViewById(R.id.imageView3);
       // listView[0].setOnItemClickListener
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int i, long id) {
               /* Intent intent=new Intent(MainActivity.this,DetailActivity.class);
                intent.putExtra("country",country[i]);
                intent.putExtra("lion",lion[i]);
              // / lastClickedRowImage = view.findViewById(R.id.listview);
                startActivity(intent);*/
        ///   listView.setImageResource(R.drawable.lion[i]);
                imageView.setImageResource(lion[i]);
            }
        });

    }

    @Override
    public void onClick(View v) {
        lastClickedRowImage.setImageResource(R.drawable.lion1);

    }
}
