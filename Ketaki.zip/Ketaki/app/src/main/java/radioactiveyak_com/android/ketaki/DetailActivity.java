package radioactiveyak_com.android.ketaki;

import android.media.Image;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.widget.ImageView;

public class DetailActivity extends AppCompatActivity {

    Toolbar toolBar;
    ImageView imageView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);

        toolBar=(Toolbar) findViewById(R.id.toolbar2);
        imageView=(ImageView) findViewById(R.id.imageView2);

        Bundle bundle=getIntent().getExtras();
        if(bundle!=null){
            toolBar.setTitle(bundle.getString("country"));
            imageView.setImageResource(bundle.getInt("lion"));

        }
    }
}
