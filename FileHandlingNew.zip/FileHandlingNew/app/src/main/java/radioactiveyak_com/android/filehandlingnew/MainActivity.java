package radioactiveyak_com.android.filehandlingnew;

import android.Manifest;
import android.os.Environment;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;

public class MainActivity extends AppCompatActivity {
    EditText e1;
    Button b1, b2, b3, b4;
    TextView tv;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        e1 = findViewById(R.id.editText);
        b1 = findViewById(R.id.button);
        b2 = findViewById(R.id.button2);
        b3 = findViewById(R.id.button3);
        b4 = findViewById(R.id.button4);
        tv=findViewById(R.id.textView);

        ActivityCompat.requestPermissions(this,new String[]{Manifest.permission.READ_EXTERNAL_STORAGE},1);
        ActivityCompat.requestPermissions(this,new String []{Manifest.permission.WRITE_EXTERNAL_STORAGE},1);

        write_internal();
        read_internal();
        write_external();
        read_external();
    }

    public void write_internal() {
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    String name=e1.getText().toString();
                    OutputStreamWriter os = new OutputStreamWriter(openFileOutput("saloni.txt", MODE_PRIVATE));
                    os.write(name);
                    os.close();
                    Toast.makeText(getApplicationContext(),"write successfully",Toast.LENGTH_LONG).show();


                }
                catch (FileNotFoundException e) {
                    e.printStackTrace();
                }
                catch (IOException e) {
                    e.printStackTrace();
                }
            }
        });

    }
    public void read_internal(){
        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try{
                    InputStreamReader is=new InputStreamReader(openFileInput("saloni.txt"));
                    BufferedReader br=new BufferedReader(is);
                    String name=br.readLine();
                    tv.setText(name);
                    getFilesDir().getAbsolutePath();
                    Toast.makeText(getApplicationContext(),"path is:" +getFilesDir().getAbsolutePath(),Toast.LENGTH_LONG).show();
                }
                catch (FileNotFoundException e2){
                    e2.printStackTrace();
                }
                catch (IOException e2){
                    e2.printStackTrace();
                }
            }
        });


    }
    public void write_external(){
        b3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
            String state=Environment.getExternalStorageState();

            if (Environment.MEDIA_MOUNTED.equals(state))
            {
                File root=Environment.getExternalStorageDirectory();
                File dir=new File(root.getAbsolutePath()+"/esefile");
                if(!dir.exists())
                {
                    dir.mkdir();
                }

                File file=new File(dir,"ese.txt");
                String msg=e1.getText().toString();

                try{
                    FileOutputStream fos=new FileOutputStream(file);
                    fos.write(msg.getBytes());
                    e1.setText("");
                    Toast.makeText(getApplicationContext(),"written successfully..",Toast.LENGTH_LONG).show();

                }
                catch (Exception e){
                    e.printStackTrace();
                }
            }
            else
            {
                Toast.makeText(getApplicationContext(),"file not found",Toast.LENGTH_LONG).show();
            }

            }
        });

    }
    public void read_external(){
        b4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                File root=Environment.getExternalStorageDirectory();
                File dir=new File(root.getAbsolutePath()+"/esefile");
                File file=new File(dir,"ese.txt");
                String str;
                StringBuffer sb=new StringBuffer();
                try{
                    FileInputStream fis=new FileInputStream(file);
                    InputStreamReader is=new InputStreamReader(fis);
                    BufferedReader br=new BufferedReader(is);
                    while((str=br.readLine())!=null){
                        sb.append(str);
                    }
                    tv.setText(sb.toString());
                    Toast.makeText(getApplicationContext(),sb.toString(),Toast.LENGTH_LONG).show();


                }
                catch (Exception e){
                    e.printStackTrace();
                }
            }
        });
    }
}