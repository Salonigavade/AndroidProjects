package radioactiveyak_com.android.app_bmi;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    TextView t1,t2,t3;
    EditText ed1,ed2;
    Button b1;
    public String s1="";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ed1=(EditText)findViewById(R.id.editText);
        ed2=(EditText)findViewById(R.id.editText2);

        b1=(Button)findViewById(R.id.button);

        t1=(TextView)findViewById(R.id.textView);
        t2=(TextView)findViewById(R.id.textView2);
        t3=(TextView)findViewById(R.id.textView4);

        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String W=ed1.getText().toString();
                double Wt=Integer.parseInt(W);
                String H=ed2.getText().toString();
                double Ht=Integer.parseInt(H);
                double bmi=Wt/(Ht*Ht);

                bmi=bmi*10000;

                if(bmi<18.5)
                    s1="UnderWeight";
                else if (bmi>=18.5 && bmi<24.9)
                    s1="Normal";
                else if (bmi>=25 && bmi<29.9)
                    s1="Overweight";
                else if (bmi>=30)
                    s1="Obese";
                else
                    s1="Too Much fat";

                t3.setText("BMI:\n"+String.valueOf(bmi)+ s1);
            }
        });
    }
}
