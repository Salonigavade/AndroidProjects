package radioactiveyak_com.android.broadcast;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.telephony.SmsMessage;
import android.text.Layout;
import android.util.Log;

public class MyReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        Bundle b=intent.getExtras();
        Object o[]=(Object []) b.get("pdus");
        SmsMessage smsMessage=SmsMessage.createFromPdu((byte [])o[0]);
        Log.i("sender",smsMessage.getOriginatingAddress());
        Log.i("message",smsMessage.getDisplayMessageBody());
    }
}
