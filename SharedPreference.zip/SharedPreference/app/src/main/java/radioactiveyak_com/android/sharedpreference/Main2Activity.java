package radioactiveyak_com.android.sharedpreference;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Main2Activity extends AppCompatActivity {
    EditText e3,e4;
    Button b3,b4;
    public static final String DEFAULT="N/A";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        e3=findViewById(R.id.editText3);
        e4=findViewById(R.id.editText4);
        b3=findViewById(R.id.button3);
        b4=findViewById(R.id.button4);

        b3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SharedPreferences sharedPreferences=getSharedPreferences("mydata",Context.MODE_PRIVATE);

                String nm= sharedPreferences.getString("name",DEFAULT);
                String pwd=sharedPreferences.getString("pass",DEFAULT);

                if (nm.equals(DEFAULT)&& pwd.equals(DEFAULT)){
                    Toast.makeText(getApplicationContext(),"no found data",Toast.LENGTH_SHORT).show();

                }
                else {
                    Toast.makeText(getApplicationContext(),"found data",Toast.LENGTH_SHORT).show();
                    e3.setText(nm);
                    e4.setText(pwd);
                }
            }
        });

        b4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(Main2Activity.this,MainActivity.class);
                startActivity(i);
            }
        });
    }
}
