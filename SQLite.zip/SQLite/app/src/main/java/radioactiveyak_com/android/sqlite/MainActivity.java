package radioactiveyak_com.android.sqlite;

import android.content.Intent;
import android.database.Cursor;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
DatabaseHelper mydb;
EditText e1,e2,e3,e4;
Button b1,b2,b3,b4,b5;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mydb=new DatabaseHelper(this);

        e1=findViewById(R.id.editText);
        e2=findViewById(R.id.editText2);
        e3=findViewById(R.id.editText3);
        e4=findViewById(R.id.editText4);
        b1=findViewById(R.id.button);
        b2=findViewById(R.id.button2);
        b3=findViewById(R.id.button3);
        b4=findViewById(R.id.button4);
        b5=findViewById(R.id.button5);

        b5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(MainActivity.this,Main2Activity.class);
                startActivity(i);
            }
        });

        AddData();
        view();
        updateData();
        delete();
    }
    public void AddData(){
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
             boolean isInserted=   mydb.insertData(e1.getText().toString(),
                        e2.getText().toString(),
                        e3.getText().toString());

                User user=new User(MainActivity.this);
                user.setName(e1.getText().toString());

                if(isInserted==true)
                    Toast.makeText(getApplicationContext(),"Inserted",Toast.LENGTH_LONG).show();
                else
                    Toast.makeText(getApplicationContext(),"Error",Toast.LENGTH_LONG).show();
                e1.setText("");
                e2.setText("");
                e3.setText("");
            }
        });
    }

    public void view(){
        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Cursor res=mydb.getAllData();
                if (res.getCount()==0) {
                    showmsg("Error","Ntg to show");
                    return ;
                }
                StringBuffer sb=new StringBuffer();
                while (res.moveToNext()){
                    sb.append("ID :"+res.getString(0)+"\n"
                            +"Name:"+res.getString(1)+"\n"
                            +"Surname:"+res.getString(2)+"\n"
                            +"Marks:"+res.getString(3)+"\n\n");

                }
                //shoe all data
                showmsg("Data:",sb.toString());
            }
        });
    }
    public void showmsg(String title,String msg){
        AlertDialog.Builder builder=new AlertDialog.Builder(this);
        builder.setCancelable(true);
        builder.setTitle(title);
        builder.setMessage(msg);
        builder.show();
    }
    public void updateData(){
        b3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                boolean isUpdate=mydb.updateData(e4.getText().toString(),
                        e1.getText().toString(),
                        e2.getText().toString(),
                        e3.getText().toString());
                if (isUpdate==true)
                    Toast.makeText(getApplicationContext(),"Updated",Toast.LENGTH_LONG).show();
                else
                    Toast.makeText(getApplicationContext(),"Error",Toast.LENGTH_LONG).show();

            }
        });
    }

    public void delete(){
        b4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int deleteRows=mydb.deleteData(e4.getText().toString());
                if (deleteRows!=0)
                    Toast.makeText(getApplicationContext(),"Deleted",Toast.LENGTH_LONG).show();
                else
                    Toast.makeText(getApplicationContext(),"Error",Toast.LENGTH_LONG).show();

            }
        });
    }



}
