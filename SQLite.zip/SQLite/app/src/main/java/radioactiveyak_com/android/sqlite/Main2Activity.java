package radioactiveyak_com.android.sqlite;

import android.content.Intent;
import android.database.Cursor;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Main2Activity extends MainActivity {
    EditText e1,e2;
    Button b1,b2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        e1=findViewById(R.id.editText5);
        e2=findViewById(R.id.editText6);
        b1=findViewById(R.id.button6);
        b2=findViewById(R.id.button7);

        login();
        back();
    }
    public void login(){
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Cursor c=mydb.login();
                StringBuffer sb=new StringBuffer();
                while(c.moveToNext()){
                    sb.append("ID:"+c.getString(0)+"\n"
                            +"Name:"+c.getString(1)+"\n"
                            +"Surname:"+c.getString(2)+"\n"
                            +"Marks:"+c.getString(3)+"\n\n");

                    if (e1.getText().toString().equals(c.getString(1)) && e2.getText().toString().equals(c.getString(2))){
                        showmsg("Login",sb.toString());
                        //Toast.makeText(MainActivity.this, "Login Successful", Toast.LENGTH_SHORT).show();
                        User user=new User(Main2Activity.this);
                        user.setName(e1.getText().toString());

                        Intent i=new Intent(Main2Activity.this,Main3Activity.class);
                        startActivity(i);

                    }
                    else{
                        Toast.makeText(getApplicationContext(),"Invalid user",Toast.LENGTH_LONG).show();
                    }


                }
            }
        });
    }
    public void back(){
        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(Main2Activity.this,MainActivity.class);
                startActivity(i);
            }
        });
    }
}
