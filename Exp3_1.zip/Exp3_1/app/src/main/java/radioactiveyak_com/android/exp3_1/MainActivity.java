package radioactiveyak_com.android.exp3_1;

import android.app.Activity;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements AdapterView.OnItemSelectedListener{
String f_unm,s_unm,l_unm,f_pwd,s_pwd,l_pwd;
String [] info={"Faculty","Student","LabAssistant"};
EditText ed1,ed2;
Button b1,b2;
Spinner sp;
String e,p,s;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        sp=findViewById(R.id.spinner);
        ed1=findViewById(R.id.editText);
        ed2=findViewById(R.id.editText2);
        b1=findViewById(R.id.button);
        b2=findViewById(R.id.button2);

        ArrayAdapter arrayAdapter=new ArrayAdapter(this,android.R.layout.simple_spinner_item,info);
        arrayAdapter.setDropDownViewResource(R.layout.support_simple_spinner_dropdown_item);
        sp.setAdapter(arrayAdapter);
        sp.setOnItemSelectedListener((AdapterView.OnItemSelectedListener) this);




/**        sp.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

                Toast.makeText(getApplicationContext(),parent.getItemAtPosition(position).toString(),Toast.LENGTH_LONG).show();
                //s=parent.getSelectedItemPosition(position).toString();
                s=sp.getSelectedItem().toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }


        });*/

        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //String s=getItemAtPosition(position).toString();
                e = String.valueOf(ed1.getText());
                p = String.valueOf(ed2.getText());
                s = sp.getSelectedItem().toString();
                Toast.makeText(getApplicationContext(), s, Toast.LENGTH_SHORT).show();
                if (e.equals(p)) {
                    Toast.makeText(getApplicationContext(), "entered", Toast.LENGTH_SHORT).show();
                    if (s.equals("Faculty")) {
                        Intent intent;
                        intent = new Intent(getApplicationContext(), Facultyctivity.class);
                        startActivity(intent);
                    } else if (s.equals("Student")) {
                        Intent intent;
                        intent = new Intent(getApplicationContext(), StudentActivity.class);
                        startActivity(intent);
                    } else if (s.equals("LabAssistant")) {
                        Intent intent;
                        intent = new Intent(getApplicationContext(), LabAssistantActivity.class);
                        startActivity(intent);
                    }

                } else {
                    Toast.makeText(getApplicationContext(), "Login failed", Toast.LENGTH_SHORT).show();
                }
            }
        });

        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ed1.setText("");
                ed2.setText("");
            }
        });
    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }
}
