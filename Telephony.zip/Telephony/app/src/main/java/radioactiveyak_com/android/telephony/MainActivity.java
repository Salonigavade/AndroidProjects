package radioactiveyak_com.android.telephony;

import android.Manifest;
import android.content.pm.PackageManager;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.telephony.TelephonyManager;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    Button b1,b2;
    TelephonyManager tm;
    SmsManager sms;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        b1 = findViewById(R.id.button);
        b2=findViewById(R.id.button2);

        ActivityCompat.requestPermissions(this,new String[]{Manifest.permission.SEND_SMS},1);

        tm = (TelephonyManager) getSystemService(TELEPHONY_SERVICE);
        final String simop = tm.getSimOperatorName();
        final int networktype = tm.getNetworkType();
        String nm;
        switch (networktype) {
            case TelephonyManager.NETWORK_TYPE_CDMA:
                nm = "CDMA";
                break;
            case TelephonyManager.NETWORK_TYPE_GPRS:
                nm = "GPRS";
                break;
            case TelephonyManager.NETWORK_TYPE_EDGE:
                nm = "EDGE";
                break;
            case TelephonyManager.NETWORK_TYPE_UNKNOWN:
                nm = "UNKNOWN";
                break;
        }
        final int phonetype = tm.getPhoneType();
        String phnm;
        switch (phonetype) {
            case TelephonyManager.PHONE_TYPE_CDMA:
                phnm = "CDMA";
                break;
            case TelephonyManager.PHONE_TYPE_GSM:
                phnm = "GSM";
                break;
            case TelephonyManager.PHONE_TYPE_NONE:
                phnm = "NONE";
                break;
        }

//        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) {
//          final int simcount = tm.getPhoneCount();
//        }
//
//        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED) {
//            // TODO: Consider calling
//            //    ActivityCompat#requestPermissions
//            // here to request the missing permissions, and then overriding
//            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
//            //                                          int[] grantResults)
//            // to handle the case where the user grants the permission. See the documentation
//            // for ActivityCompat#requestPermissions for more details.
//            /////String imi = tm.getImei();
//
//            return;
//        }

        final String iso1=tm.getNetworkCountryIso();
        final String iso2=tm.getSimCountryIso();

        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Toast.makeText(getApplicationContext(),"Simop:"+simop+
                        "\nNetworkType:"+networktype+
                        "\nPhonetype:"+phonetype+
                        "\nsimcnt:"+
                        "\niso1:"+iso1+
                        "\niso2:"+iso2+"\n",Toast.LENGTH_LONG).show();

            }
        });


        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                sms=SmsManager.getDefault();
                sms.sendTextMessage("+919527524226","+919527524226","Hello",null,null);
                Toast.makeText(getApplicationContext(),"Sms send",Toast.LENGTH_LONG).show();

            }
        });
    }

}
