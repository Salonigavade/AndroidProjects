package radioactiveyak_com.android.customelist;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

public class MainActivity extends AppCompatActivity {

    Toolbar mtoolbar;
    ListView mlistview;

    String[] country={"a","b","c","d"};
    int[] curtains={R.drawable.lion,
    R.drawable.lion2,
    R.drawable.lion3,
    R.drawable.lion4};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mtoolbar=(Toolbar) findViewById(R.id.toolbar);
        mtoolbar.setTitle(getResources().getString(R.string.app_name));
        mlistview=(ListView) findViewById(R.id.ListView);
        MyAdapter myAdapter = new MyAdapter(MainActivity.this, country, curtains);
        mlistview.setAdapter(myAdapter);
        mlistview.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Intent mIntent = new Intent(MainActivity.this, DetailActivity.class);
                mIntent.putExtra("countryName", country[i]);
                mIntent.putExtra("countryFlag", curtains[i]);
                startActivity(mIntent);
            }
        });

    }
}
