package radioactiveyak_com.android.customelist;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.widget.ImageView;

public class DetailActivity extends AppCompatActivity {

    Toolbar mtoolbar;
    ImageView imageview;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);
        mtoolbar = (Toolbar) findViewById(R.id.toolbar2);
        imageview = (ImageView) findViewById(R.id.imageView2);

        Bundle mBundle = getIntent().getExtras();
        if (mBundle != null) {
            mtoolbar.setTitle(mBundle.getString("countryName"));
            imageview.setImageResource(mBundle.getInt("countryFlag"));
        }
    }
}
